﻿using ABCRetailers.Services;
using Microsoft.AspNetCore.Mvc;

namespace ABCRetailers.Controllers
{
    public class UploadController : Controller
    {
        private readonly IAzureStorageService _storageService;

        public UploadController(IAzureStorageService storageService)
        {
            _storageService = storageService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadContract(IFormFile contractFile)
        {
            if (contractFile != null && contractFile.Length > 0)
            {
                var result = await _storageService.UploadFileAsync(
                    contractFile,
                    "contracts",
                    "dummy-contracts" 
                );

                ViewBag.Message = result;
            }
            else
            {
                ViewBag.Message = "Please select a file to upload.";
            }

            return View("Index");
        }
    }
}
