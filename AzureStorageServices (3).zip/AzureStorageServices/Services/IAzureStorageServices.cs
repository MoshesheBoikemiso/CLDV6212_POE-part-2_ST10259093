﻿using ABCRetailers.Models;

namespace ABCRetailers.Services
{
    public interface IAzureStorageService
    {
        Task<List<Customer>> GetCustomersAsync();
        Task<Customer> GetCustomerAsync(string rowKey);
        Task<Customer> AddCustomerAsync(Customer customer);
        Task<Customer> UpdateCustomerAsync(Customer customer);
        Task<bool> DeleteCustomerAsync(string rowKey);

        Task<List<Product>> GetProductsAsync();
        Task<Product> GetProductAsync(string rowKey);
        Task<Product> AddProductAsync(Product product, IFormFile imageFile);
        Task<Product> UpdateProductAsync(Product product, IFormFile? imageFile);
        Task<bool> DeleteProductAsync(string rowKey);

        Task<bool> SendMessageAsync(string queueName, string message);

        Task<string> UploadFileAsync(IFormFile file, string shareName, string directoryName);
    }
}