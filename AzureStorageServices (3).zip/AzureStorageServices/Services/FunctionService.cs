﻿using System.Text;
using System.Text.Json;

namespace ABCRetailers.Services
{
    public class FunctionsService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public FunctionsService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _configuration = configuration;
        }

        public async Task<string> StoreProductAsync(object product)
        {
            var functionUrl = "https://functionapp10259093-hnddd0e0gscne9aa.canadacentral-01.azurewebsites.net/api/StoreProduct?code=vT4jHHUJJoy1TV0vA_pZV_GS1nrBv1xTdw36stUnYzBHAzFuvrh8yA==";

            var json = JsonSerializer.Serialize(product);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(functionUrl, content);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> UploadImageAsync(IFormFile imageFile)
        {
            var functionUrl = "https://functionapp10259093-hnddd0e0gscne9aa.canadacentral-01.azurewebsites.net/api/UploadImage?code=2k5KdvRMSBVrv8vHTIPMNCj3APCbg_RjVS_gL1zWHomYAzFuLEllXw==";

            using var formData = new MultipartFormDataContent();
            using var stream = imageFile.OpenReadStream();
            formData.Add(new StreamContent(stream), "image", imageFile.FileName);

            var response = await _httpClient.PostAsync(functionUrl, formData);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> QueueOrderAsync(object order)
        {
            var functionUrl = "https://functionapp10259093-hnddd0e0gscne9aa.canadacentral-01.azurewebsites.net/api/QueueOrder?code=vG_LnFeiXJUyY_MDL6RfWddkuMmHZ7k1oBaSJ_cvmfFaAzFuyBxoFw==";

            var json = JsonSerializer.Serialize(order);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(functionUrl, content);
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> GenerateReportAsync(object reportData)
        {
            var functionUrl = "https://functionapp10259093-hnddd0e0gscne9aa.canadacentral-01.azurewebsites.net/api/GenerateReport?code=kFWE0f6xD5B2PBKEKDo2ExzBwtfYgGtteIJrP42cUzZ1AzFuEqni9A==";

            var json = JsonSerializer.Serialize(reportData);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(functionUrl, content);
            return await response.Content.ReadAsStringAsync();
        }
    }
}