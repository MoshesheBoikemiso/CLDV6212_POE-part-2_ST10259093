﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure.Storage.Blobs;
using System.Text.Json;

namespace ABCRetailers.Functions
{
    public class UploadImageFunction
    {
        private readonly ILogger<UploadImageFunction> _logger;

        public UploadImageFunction(ILogger<UploadImageFunction> logger)
        {
            _logger = logger;
        }

        [Function("UploadImage")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request to upload image.");

            try
            {
                var body = await new StreamReader(req.Body).ReadToEndAsync();
                var formData = JsonSerializer.Deserialize<FormData>(body);

                if (string.IsNullOrEmpty(formData?.ImageBase64))
                {
                    var badRequest = req.CreateResponse(System.Net.HttpStatusCode.BadRequest);
                    await badRequest.WriteStringAsync("No image data provided");
                    return badRequest;
                }

                var connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
                var blobServiceClient = new BlobServiceClient(connectionString);
                var containerClient = blobServiceClient.GetBlobContainerClient("product-images");
                await containerClient.CreateIfNotExistsAsync();

                var fileName = $"{Guid.NewGuid()}.jpg"; 
                var blobClient = containerClient.GetBlobClient(fileName);

                var imageBytes = Convert.FromBase64String(formData.ImageBase64);
                using var stream = new MemoryStream(imageBytes);
                await blobClient.UploadAsync(stream, overwrite: true);

                var imageUrl = blobClient.Uri.ToString();
                _logger.LogInformation($"Image uploaded successfully: {imageUrl}");

                var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
                await response.WriteAsJsonAsync(new
                {
                    message = "Image uploaded successfully",
                    imageUrl = imageUrl
                });
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error uploading image: {ex.Message}");
                return req.CreateResponse(System.Net.HttpStatusCode.InternalServerError);
            }
        }
    }

    public class FormData
    {
        public string ImageBase64 { get; set; }
        public string FileName { get; set; }
    }
}