﻿using System;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure.Data.Tables;
using Azure.Storage.Queues;
using ABCRetailers.Functions.Models;

namespace ABCRetailers.Functions
{
    public class ProcessOrderFunction
    {
        private readonly ILogger<ProcessOrderFunction> _logger;

        public ProcessOrderFunction(ILogger<ProcessOrderFunction> logger)
        {
            _logger = logger;
        }

        [Function("QueueOrder")]
        public async Task<HttpResponseData> QueueOrder(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("C# HTTP trigger function processing order via queue.");

            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var order = JsonSerializer.Deserialize<Order>(requestBody);

                if (order == null)
                {
                    var badRequest = req.CreateResponse(System.Net.HttpStatusCode.BadRequest);
                    await badRequest.WriteStringAsync("Invalid order data");
                    return badRequest;
                }

                var connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
                var queueClient = new QueueClient(connectionString, "orders");
                await queueClient.CreateIfNotExistsAsync();

                var orderJson = JsonSerializer.Serialize(order);
                await queueClient.SendMessageAsync(orderJson);

                var tableClient = new TableClient(connectionString, "Orders");
                await tableClient.CreateIfNotExistsAsync();
                await tableClient.UpsertEntityAsync(order);

                _logger.LogInformation($"Order {order.RowKey} queued and stored in Table Storage");

                var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
                await response.WriteAsJsonAsync(new
                {
                    message = "Order processed successfully",
                    orderId = order.RowKey,
                    status = "Queued and Stored"
                });
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing order: {ex.Message}");
                return req.CreateResponse(System.Net.HttpStatusCode.InternalServerError);
            }
        }
    }
}