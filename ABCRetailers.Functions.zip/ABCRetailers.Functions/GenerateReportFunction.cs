﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure.Storage.Files.Shares;

namespace ABCRetailers.Functions
{
    public class GenerateReportFunction
    {
        private readonly ILogger<GenerateReportFunction> _logger;

        public GenerateReportFunction(ILogger<GenerateReportFunction> logger)
        {
            _logger = logger;
        }

        [Function("GenerateReport")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request to generate report.");

            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

                var reportContent = $"ABC Retailers Sales Report\nGenerated: {DateTime.Now}\n\n{requestBody}";

                var connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
                var shareClient = new ShareClient(connectionString, "reports");
                await shareClient.CreateIfNotExistsAsync();

                var directoryClient = shareClient.GetDirectoryClient("sales-reports");
                await directoryClient.CreateIfNotExistsAsync();

                var fileName = $"sales_report_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
                var fileClient = directoryClient.GetFileClient(fileName);

                await fileClient.CreateAsync(reportContent.Length);
                using var stream = new MemoryStream(Encoding.UTF8.GetBytes(reportContent));
                await fileClient.UploadRangeAsync(new Azure.HttpRange(0, stream.Length), stream);

                _logger.LogInformation($"Report generated successfully: {fileName}");

                var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
                await response.WriteAsJsonAsync(new
                {
                    message = "Report generated successfully",
                    fileName = fileName,
                    filePath = fileClient.Path
                });
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error generating report: {ex.Message}");
                return req.CreateResponse(System.Net.HttpStatusCode.InternalServerError);
            }
        }
    }
}