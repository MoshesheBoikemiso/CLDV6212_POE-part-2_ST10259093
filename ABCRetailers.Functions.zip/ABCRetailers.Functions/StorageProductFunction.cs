﻿using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure.Data.Tables;
using ABCRetailers.Functions.Models;

namespace ABCRetailers.Functions
{
    public class StoreProductFunction
    {
        private readonly ILogger<StoreProductFunction> _logger;

        public StoreProductFunction(ILogger<StoreProductFunction> logger)
        {
            _logger = logger;
        }

        [Function("StoreProduct")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request to store product.");

            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var product = JsonSerializer.Deserialize<Product>(requestBody);

                if (product == null)
                {
                    var badRequest = req.CreateResponse(System.Net.HttpStatusCode.BadRequest);
                    await badRequest.WriteStringAsync("Invalid product data");
                    return badRequest;
                }

                if (string.IsNullOrEmpty(product.RowKey))
                {
                    product.RowKey = Guid.NewGuid().ToString();
                }

                var connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
                var tableClient = new TableClient(connectionString, "Products");
                await tableClient.CreateIfNotExistsAsync();
                await tableClient.UpsertEntityAsync(product);

                _logger.LogInformation($"Product {product.ProductName} stored successfully with ID: {product.RowKey}");

                var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
                await response.WriteAsJsonAsync(new
                {
                    message = "Product stored successfully",
                    productId = product.RowKey
                });
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error storing product: {ex.Message}");
                return req.CreateResponse(System.Net.HttpStatusCode.InternalServerError);
            }
        }
    }
}